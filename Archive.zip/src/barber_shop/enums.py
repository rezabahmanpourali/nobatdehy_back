import enum

class BarberShopType(enum.Enum):
    SEEN_RECENTLY = "SEEN_RECENTLY"
    TOP_BARBERS = "TOP_BARBERS"
    HOTTEST_BARBERS = "HOTTEST_BARBERS"